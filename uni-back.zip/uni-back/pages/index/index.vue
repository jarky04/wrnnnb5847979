<template>
	<view class="content">
		<text class="title">{{title}}</text>
		<mask v-if="showMask"></mask>
		<button type="primary" @click="onClick">显示遮罩</button>
    <view class="desc">
      <text>遮罩处于显示状态时，点击返回会先关闭遮罩。待遮罩关闭后，再点击才会走返回的默认逻辑。</text>
    </view>
	</view>
</template>

<script>
import mask from '../../components/mask.vue';
export default {
	data() {
		return {
			title: 'onBackPress',
			showMask: false
		};
	},
	components: {
		mask
	},
	onBackPress() {
		if (this.showMask) {
			this.showMask = false;
			return true;
		} else {
			uni.showModal({
				title: '提示',
				content: '是否退出uni-app？',
				success: function(res) {
					if (res.confirm) {
						// 退出当前应用，改方法只在App中生效
						plus.runtime.quit();
					} else if (res.cancel) {
						console.log('用户点击取消');
					}
				}
			});
			return true;
		}
	},
	methods: {
		onClick() {
			this.showMask = true;
		}
	}
};
</script>

<style>
.content {
	flex: 1;
	justify-content: center;
	align-items: center;
	flex-direction: column;
}

.title {
	font-size: 36upx;
	color: #8f8f94;
}
.desc {
	padding: 50upx;
}
</style>
