<template>
	<view>
		<view class="cpt-mask">
		</view>
	</view>
</template>

<script>
	export default {}
</script>

<style>
	.cpt-mask {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: #000000;
		opacity: 0.5;
		z-index: 99;
	}
</style>
