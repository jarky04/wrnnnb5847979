export default {
	minHeight: 600,
	minWidth: 1200
}
