const base_url = 'https://result.eolinker.com/GzWguRJbc6216d987a858b371cd2e4973b84ea5ed45cb4e?uri=xxsy.1i2.cn/index/'

let apis = {}

apis.member_reAuth = base_url + 'member/reAuth'
apis.member_login = base_url + 'member/login'
apis.read_info = base_url + 'read/info'
apis.read_auth = base_url + 'read/vResourceAuth'
apis.read_rstep = base_url + 'read/rstep'
apis.read_saveRstep = base_url + 'read/saveRstep'
apis.read_show = base_url + 'read/show'
apis.read_article = base_url + 'read/article'
apis.read_showart = base_url + 'read/showart'

export default apis