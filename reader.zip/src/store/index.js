import Vuex from 'vuex'
import Vue from 'vue'
import setting from '@/common/setting.js'
Vue.use(Vuex)

const store = new Vuex.Store({
	state: {
		themaIndex: 4,
		themaList: ['yellow', 'green', 'blue', 'grey', 'pink', 'dark', 'darker'],
		themaColor: ['#ede8d5', '#ede8d5', '#ede8d5', '#ede8d5', '#ede8d5', '#ede8d5', '#ede8d5'],
		fontSize: 16,
		mainHeight: 600
	},
	getters: {
		themaName(state) {
			return state.themaList[state.themaIndex]
		}
	},
	mutations: {
		setThema(state, index) {
			state.themaIndex = index
		},
		setMainHeight(state, height) {
			state.mainHeight = Math.max(setting.minHeight, height)
		},
		fontSizePlus(state) {
			if (state.fontSize >= 24) {
				return false
			}
			state.fontSize++
		},
		fontSizeMinus(state) {
			if (state.fontSize <= 12) {
				return false
			}
			state.fontSize--
		}
	}
})


export default store;
