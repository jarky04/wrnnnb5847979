<template>
	<div class="catalogue" :class="open ? '' : 'hide'">
		<div class="catalogue-left" @click="toggle">
			<span class="catalogue-left-text">章节目录</span>
			<span class="catalogue-left-icon"><i class="icon hover fa fa-list catalogue-icon" aria-hidden="true"></i></span>
		</div>
		<div class="catalogue-right" :style="{height:mainHeight+'px'}">
			<div class="catalogue-list"></div>
		</div>
	</div>
</template>

<script>
import { mapState } from 'vuex';
export default {
	props: {},
	data() {
		return {
			open: false
		};
	},
	computed: {
		...mapState({
			mainHeight: 'mainHeight'
		})
	},
	methods: {
		toggle() {
			this.open = !this.open;
		}
	}
};
</script>

<style scoped="" lang="scss">
$tool-bar-offset: 20px;
$tool-icon-height: 40px;
$tool-icon-index: 1;
$right-panel-offset: - $tool-bar-offset - $tool-icon-height * $tool-icon-index;
.catalogue {
	position: relative;
	text-align: center;
	line-height: 40px;
	height: 40px;
	&-left {
		position: absolute;
		background-color: #f7f7f7;
		line-height: 40px;
		font-size: 0;
		white-space: nowrap;
		right: 0;
		top: 0;
		cursor: pointer;
		&-text {
			display: inline-block;
			vertical-align: middle;
			font-size: 14px;
			padding-left: 20px;
		}
		&-icon {
			display: inline-block;
			vertical-align: middle;
			width: 50px;
			font-size: 24px;
		}
	}
	&-right {
		position: absolute;
		left: 100%;
		top: $right-panel-offset;
		width: 610px;
		height: auto;
		text-align: left;
		background-color: #f7f7f7;
		box-shadow: #dddddd 5px 5px 10px;
		padding: 25px;
		
	}
}

.catalogue.hide {
	.catalogue-left {
		background-color: transparent;
		.catalogue-left-text {
			display: none;
		}
	}
	.catalogue-right {
		display: none;
	}
}
</style>
