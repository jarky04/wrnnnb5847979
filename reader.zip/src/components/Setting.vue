<template>
	<div class="setting" :class="open ? '' : 'hide'">
		<div class="setting-left" @click="toggle">
			<span class="setting-left-text">显示设置</span>
			<span class="setting-left-icon"><i class="icon hover fa fa-cog setting-icon" aria-hidden="true"></i></span>
		</div>
		<div class="setting-right">
			<div class="setting-title">设置</div>
			<div class="setting-row">
				<span class="setting-row-left">阅读主题</span>
				<div class="setting-row-right">
					<div class="setting-thema">
						<span v-for="(item, index) in themaColor" :key="index" :style="{ backgroundColor: item }" :class="{ act: themaIndex === index }" @click="setThema(index)">
							<i class="fa fa-check" aria-hidden="true"></i>
						</span>
					</div>
				</div>
			</div>
			<div class="setting-row">
				<span class="setting-row-left">字体大小</span>
				<div class="setting-row-right">
					<div class="setting-fontSize">
						<span @click="fontSizeMinus"><i class="fa fa-minus" aria-hidden="true"></i></span>
						<span>{{ fontSize }}</span>
						<span @click="fontSizePlus"><i class="fa fa-plus" aria-hidden="true"></i></span>
					</div>
				</div>
			</div>
			<div class="setting-row">
				<span class="setting-row-left">阅读方式</span>
				<div class="setting-row-right">
					<div class="setting-fontSize">
						<span @click="fontSizeMinus"><i class="fa fa-minus" aria-hidden="true"></i></span>
						<span>{{ fontSize }}</span>
						<span @click="fontSizePlus"><i class="fa fa-plus" aria-hidden="true"></i></span>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import { mapState, mapMutations } from 'vuex';
export default {
	props: {},
	data() {
		return {
			open: false
		};
	},
	computed: {
		...mapState({
			themaIndex: 'themaIndex',
			themaList: 'themaList',
			themaColor: 'themaColor',
			fontSize: 'fontSize'
		})
	},
	methods: {
		...mapMutations({
			setThema: 'setThema',
			fontSizePlus: 'fontSizePlus',
			fontSizeMinus: 'fontSizeMinus'
		}),
		toggle() {
			this.open = !this.open;
		}
	}
};
</script>

<style scoped="" lang="scss">
$tool-bar-offset: 20px;
$tool-icon-height: 40px;
$tool-icon-index: 0;
$right-panel-offset: - $tool-bar-offset - $tool-icon-height * $tool-icon-index;
.setting {
	position: relative;
	text-align: center;
	line-height: 40px;
	height: 40px;
	&-left {
		position: absolute;
		background-color: #f7f7f7;
		line-height: 40px;
		font-size: 0;
		white-space: nowrap;
		right: 0;
		top: 0;
		cursor: pointer;
		&-text {
			display: inline-block;
			vertical-align: middle;
			font-size: 14px;
			padding-left: 20px;
		}
		&-icon {
			display: inline-block;
			vertical-align: middle;
			width: 50px;
			font-size: 24px;
		}
	}
	&-right {
		position: absolute;
		left: 100%;
		top: $right-panel-offset;
		width: 360px;
		height: auto;
		text-align: left;
		background-color: #f7f7f7;
		box-shadow: #dddddd 5px 5px 10px;
		padding: 25px 60px 25px 25px;
		.setting-title {
			font-size: 16px;
			line-height: 20px;
			font-weight: bold;
			text-align: left;
		}
		.setting-row {
			display: flex;
			margin-top: 15px;
			&-left {
				display: inline-block;
				width: 80px;
				font-size: 14px;
			}
			&-right {
				flex: 1;
				line-height: 40px;
				.setting-thema {
					span {
						display: inline-block;
						vertical-align: middle;
						width: 38px;
						height: 38px;
						line-height: 38px;
						text-align: center;
						border-radius: 100px;
						border: solid 1px #dddddd;
						margin: 0px 10px 10px 0px;
						cursor: pointer;
						i {
							font-size: 20px;
							color: #ff7171;
							vertical-align: middle;
							display: none;
						}
						&.act {
							i {
								display: inline-block;
							}
						}
					}
				}
				.setting-fontSize {
					display: flex;
					width: 210px;
					height: 30px;
					backgroundcolor: #efefef;
					border: solid 1px #dddddd;
					line-height: 30px;
					margin-top: 4px;
					vertical-align: middle;
					span {
						position: relative;
						flex: 1;
						text-align: center;
						font-size: 14px;
						color: #999999;
						&:after {
							content: '';
							position: absolute;
							display: inline-block;
							width: 1px;
							top: 4px;
							bottom: 4px;
							right: 0;
							background-color: #dddddd;
						}
						&:first-child {
							cursor: pointer;
						}
						&:last-child {
							cursor: pointer;
						}
						&:last-child:after {
							display: none;
						}
					}
				}
			}
		}
	}
}

.setting.hide {
	.setting-left {
		background-color: transparent;
		.setting-left-text {
			display: none;
		}
	}
	.setting-right {
		display: none;
	}
}
</style>
