<template>
	<div class="side-bar paper" :class="[show ? '' : 'hide']">
		<div class="side-bar-back icon hover border">
			<a href="javascript:history.back();">
				<i class="fa fa-arrow-circle-left"></i>
				&nbsp;
				<span>退出阅读</span>
			</a>
		</div>
		<div class="side-bar-book border">
			<div class="side-bar-book-title text">书本标题书本标题书本标题书本标题书本标题asdasdasdasdasdadsadasdasdasdasdasdasdasdad</div>
			<div class="side-bar-book-cover">
				<img class="img" src="../assets/logo.png" />
				<div class="price">￥58.33</div>
			</div>
			<a class="side-bar-book-link buy" href="" target="_blank" >购买</a>
			<a class="side-bar-book-link collect" href="" target="_blank">收藏</a>
		</div>
		<div class="side-bar-tools border">
			<a class="text hover" href="" target="_blank">
				<i class="fa fa-share-alt"></i>
				<span>&nbsp;分享</span>
			</a>
			<a class="text hover" href="" target="_blank">
				<i class="fa fa-commenting"></i>
				<span>&nbsp;评论（9999）</span>
			</a>
		</div>
		<div class="side-bar-qrcode">
			<div class="side-bar-qrcode-item bg">
				<p class="icon">扫一扫手机阅读</p>
				<img src="../assets/qrcode_mobile.png" />
			</div>
			<div class="side-bar-qrcode-item bg">
				<p class="icon">手机APP下载</p>
				<img src="../assets/qrcode_mobile.png" />
			</div>
		</div>
		<span class="side-bar-controller paper icon hover" @click="toggle"><i class="fa fa-caret-left"></i></span>
	</div>
</template>

<script>
export default {
	name: 'LeftSideBar',
	data() {
		return {
			show: true
		};
	},
	methods: {
		close() {
			this.show = false;
		},
		open() {
			this.show = true;
		},
		toggle() {
			this.show = !this.show;
		}
	}
};
</script>

<style scoped="" lang="scss">
.side-bar {
	position: absolute;
	width: 140px;
	left: 0;
	top: 0;
	bottom: 0;
	box-sizing: border-box;
	padding: 10px 20px;
	transition: transform 0.3s ease;
	&.hide {
		transform: translateX(-140px);
	}
	&-back {
		line-height: 36px;
		font-size: 14px;
		border-bottom: solid 1px #dddddd;
	}
	&-book {
		padding: 15px 0px;
		border-bottom: dashed 1px #dddddd;
		&-title {
			font-size: 12px;
			line-height: 1.3em;
			word-break: break-word;
		}
		&-cover {
			position: relative;
			display: block;
			width: 100%;
			height: auto;
			min-height: 100px;
			margin-top: 10px;
			.img {
				display: block;
				width: 100%;
				height: auto;
			}
			.price {
				position: absolute;
				left: 0;
				right: 0;
				bottom: 0;
				height: 24px;
				line-height: 24px;
				text-align: center;
				font-size: 14px;
				background-color: rgba(0, 0, 0, 0.5);
				color: white;
			}
		}
		&-link {
			display: block;
			width: 100%;
			height: 26px;
			line-height: 26px;
			text-align: center;
			font-size: 14px;
			margin-top: 10px;
			border-radius: 5px;
			&.buy {
				color: white;
				background-color: #ff3300;
				border: solid 1px #cc0000;
				&:hover {
					background-color: #dd0909;
				}
			}
			&.collect {
				color: #333333;
				background-color: #ebebeb;
				border: solid 1px #cccccc;
				&:hover {
					background-color: #dddddd;
				}
			}
		}
	}
	&-tools {
		padding: 10px 0px;
		border-bottom: dashed 1px #dddddd;
		a {
			display: block;
			line-height: 30px;
			font-size: 12px;
		}
	}
	&-qrcode {
		padding: 15px 0px;
		&-item {
			padding-bottom: 10px;
			margin-bottom: 10px;
			p {
				line-height: 24px;
				font-size: 12px;
				text-align: center;
			}
			img {
				display: block;
				width: 100%;
				height: auto;
				box-sizing: border-box;
				padding: 0px 10px;
			}
		}
	}
	&-controller {
		position: absolute;
		width: 30px;
		height: 60px;
		text-align: center;
		text-indent: -5px;
		line-height: 60px;
		font-size: 30px;
		left: 100%;
		top: 50%;
		margin-top: -30px;
		border-top-right-radius: 100px;
		border-bottom-right-radius: 100px;
		cursor: pointer;
		i {
			transition: transform 0.3s ease;
		}
	}
	&.hide &-controller {
		i {
			transform: rotate(180deg);
		}
	}
}
</style>
