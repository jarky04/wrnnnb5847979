<template>
	<div class="side-bar paper" :class="[show ? '' : 'hide']">
		<div class="side-bar-title icon">大家都在看</div>
		<swiper class="side-bar-swiper" :options="swiperOption">
			<swiper-slide class="slide">
				<div class="book-item icon hover">
					<a href="" target="_blank">
						<div class="book-item-cover">
							<img class="cover" src="../assets/logo.png" />
							<div class="price">￥58.00</div>
						</div>
						<div class="book-item-title">大家都在看的书大家都在看的书</div>
					</a>
				</div>
			</swiper-slide>
			<swiper-slide class="slide">I'm Slide 2</swiper-slide>
			<swiper-slide class="slide">I'm Slide 3</swiper-slide>
			<swiper-slide class="slide">I'm Slide 4</swiper-slide>
			<div class="side-bar-swiper-pagination" slot="pagination"></div>
		</swiper>
		<span class="side-bar-controller paper icon hover" @click="toggle"><i class="fa fa-caret-right"></i></span>
	</div>
</template>

<script>
export default {
	name: 'LeftSideBar',
	data() {
		return {
			show: true,
			swiperOption: {
				autoplay: {
					delay: 3000,
					stopOnLastSlide: false,
					disableOnInteraction: false
				},
				pagination: {
					el: '.side-bar-swiper-pagination',
					clickable: true
				}
			}
		};
	},
	methods: {
		close() {
			this.show = false;
		},
		open() {
			this.show = true;
		},
		toggle() {
			this.show = !this.show;
		}
	}
};
</script>

<style scoped="" lang="scss">
.side-bar {
	position: absolute;
	width: 140px;
	right: 0;
	top: 0;
	bottom: 0;
	box-sizing: border-box;
	padding: 10px 20px;
	transition: transform 0.3s ease;
	&.hide {
		transform: translateX(140px);
	}
	&-title {
		padding: 20px 0px;
		line-height: 24px;
		text-align: center;
		font-size: 14px;
		font-weight: bold;
	}
	&-swiper {
		position: relative;
		padding-bottom: 30px;
		.slide {
			padding-bottom: 0px 15px;
			.book-item {
				margin-bottom: 15px;
				&-cover {
					position: relative;
					min-height: 100px;
					.cover {
						display: block;
						width: 100%;
						height: auto;
					}
					.price {
						position: absolute;
						left: 0;
						bottom: 0;
						right: 0;
						text-align: center;
						line-height: 24px;
						color: white;
						background-color: rgba(0, 0, 0, 0.5);
					}
				}
				&-title {
					line-height: 30px;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
				}
			}
		}
		&-pagination {
			position: absolute;
			left: 0;
			right: 0;
			bottom: -10px;
			text-align: center;
		}
	}
	&-controller {
		position: absolute;
		width: 30px;
		height: 60px;
		text-align: center;
		text-indent: 5px;
		line-height: 60px;
		font-size: 30px;
		right: 100%;
		top: 50%;
		margin-top: -30px;
		border-top-left-radius: 100px;
		border-bottom-left-radius: 100px;
		cursor: pointer;
		i {
			transition: transform 0.3s ease;
		}
	}
	&.hide &-controller {
		i {
			transform: rotate(180deg);
		}
	}
}
</style>
