<template>
	<div class="book-view paper">
		<div class="tools-left-top"><setting></setting><catalogue></catalogue></div>
		<div class="tools-right-top"></div>
		<div class="tools-right-bottom"></div>
	</div>
</template>

<script>
import Setting from '@/components/Setting.vue';
import Catalogue from '@/components/Catalogue.vue';
export default {
	name: 'BookView',
	components: {
		Setting,
		Catalogue
	},
	data() {
		return {};
	},
	methods: {}
};
</script>

<style scoped="" lang="scss">
.book-view {
	position: relative;
	width: 850px;
	height: 100%;
	margin: auto;
	.tools-left-top {
		position: absolute;
		width: 50px;
		height: auto;
		left: -50px;
		top: 20px;
	}
	.tools-right-top {
		position: absolute;
		width: 50px;
		height: auto;
		right: -50px;
		top: 20px;
	}
	.tools-left-top {
		position: absolute;
		width: 50px;
		height: auto;
		right: -50px;
		bottom: 120px;
	}
}
</style>
