import Vue from 'vue'
import App from './App.vue'
import apis from '@/common/api.js'
import axios from 'axios'
import store from'./store'
import VueAwesomeSwiper from 'vue-awesome-swiper'

import 'font-awesome/css/font-awesome.css'
import 'swiper/dist/css/swiper.css'

Vue.use(VueAwesomeSwiper)

Vue.config.productionTip = false

Vue.prototype.$apis = apis
Vue.prototype.$http = axios

new Vue({
	store,
	render: h => h(App),
}).$mount('#app')
