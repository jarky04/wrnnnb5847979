<template>
	<div id="app" :class="'thema-' + themaName">
		<book-view></book-view>
		<left-side-bar></left-side-bar>
		<right-side-bar></right-side-bar>
	</div>
</template>

<script>
import BookView from '@/components/BookView.vue';
import LeftSideBar from '@/components/LeftSideBar.vue';
import RightSideBar from '@/components/RightSideBar.vue';
import { mapGetters, mapMutations } from 'vuex';
import _ from 'lodash';
export default {
	name: 'app',
	components: {
		BookView,
		LeftSideBar,
		RightSideBar
	},
	computed: {
		...mapGetters({ themaName: 'themaName' })
	},
	created() {
		let that = this;
		that.setMainHeight(window.innerHeight);
		window.addEventListener(
			'resize',
			_.throttle(function() {
				that.setMainHeight(window.innerHeight);
			},300)
		);
	},
	methods: {
		...mapMutations({
			setMainHeight: 'setMainHeight'
		}),
		resize() {
		}
	}
};
</script>

<style lang="scss">
html {
	width: 100%;
	-webkit-text-size-adjust: none;
	-webkit-text-size-adjust: 100%;
	-ms-text-size-adjust: 100%;
	-webkit-tap-highlight-color: rgba(0, 0, 0, 0);
	height: 100%;
}

body {
	width: 100%;
	height: 100%;
	font-size: 14px;
	color: nth($color_step, 2);
	line-height: 24px;
	background: #fff;
	min-height: 100%;
	font-family: 'Microsoft Yahei', '微软雅黑', Arial, sans-serif;
}

* {
	margin: 0;
	padding: 0;
	border: 0;
}

ul,
ul li,
ol,
li {
	list-style: none outside none;
}

img {
	vertical-align: middle;
	border: none;
	width: 100%;
}

i {
	font: inherit;
}

input,
select,
option {
	vertical-align: middle;
	border-radius: 0px;
	-moz-appearance: none;
	-webkit-appearance: none;
	appearance: none;
	-webkit-tap-highlight-color: rgba(0, 0, 0, 0);
	outline: none;
}

input[type='text'],
input[type='button'],
input[type='submit'],
input[type='reset'] {
	-webkit-appearance: none;
	appearance: none;
	border-radius: 0;
	outline: none;
}

h1,
h2,
h3,
h4,
h5,
h6,
i,
strong {
	font-weight: normal;
}

select::-ms-expand {
	display: none;
}

a {
	color: nth($color_step, 2);
	color: inherit;
	text-decoration: none;
	-webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}

a:hover {
	color: nth($color_step, 2);
	color: inherit;
	text-decoration: none;
	outline: none;
}

body,
ul,
ol,
li,
p,
h1,
h2,
h3,
h4,
h5,
h6,
form,
fieldset,
table,
td,
img,
div,
dl,
dt,
dd,
input {
	margin: 0;
	padding: 0;
}

#app {
	position: relative;
	width: 100%;
	height: 100%;
	min-width: 1200px;
	min-height: 780px;
	overflow: hidden;
}
</style>
